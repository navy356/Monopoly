class Ext_Error(Exception):
			pass

class syntaxError(Exception):
			pass



